<?php
/* Developers : you can override this template from a theme with a file that has this path : 'nimble_templates/modules/{original-module-template-file-name}.php' */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

echo '<span class="sek-divider"></span>';
