<?php
/**
 * Displays footer bottom left content
 *
 * @package Cenote
 */

get_template_part( 'template-parts/footer/footer', 'info' );
